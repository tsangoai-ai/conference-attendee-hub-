import "@testing-library/jest-dom";
Object.assign(globalThis, {
  __firebase_config: { projectId: "test", apiKey: "test" },
  __app_id: "test-app",
  __initial_auth_token: undefined
});
